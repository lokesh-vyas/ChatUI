//
//  ChatCell.swift
//  ChatUITask
//
//  Created by Lokesh Vyas on 04/12/21.
//

import Foundation
import UIKit

class ChatCell: LKBaseCollectionViewCell {
    
    static let identifier = String(describing: ChatCell.self)
    
    var messageTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.text = "Sample message"
        textView.isScrollEnabled = false
        textView.isEditable = false
        textView.borderColor = UIColor.black
        textView.borderWidth = 1.0
        return textView
    }()
    
    var nameLabel: UILabel = {
        
        let lbl = UILabel()
        lbl.textAlignment = .right
        lbl.textColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        lbl.font = UIFont.boldSystemFont(ofSize: 18)
        lbl.borderColor = UIColor.black
        lbl.borderWidth = 1.0
        return lbl
    }()
    
    override func setupViews() {
        super.setupViews()
        addSubview(nameLabel)
        addSubview(messageTextView)
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.messageTextView.text = nil
    }
}
