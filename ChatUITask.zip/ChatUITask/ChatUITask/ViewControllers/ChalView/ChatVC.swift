//
//  ChatVC.swift
//  ChatUITask
//
//  Created by Lokesh Vyas on 04/12/21.
//

import UIKit

class ChatVC: UIViewController {
    
    @IBOutlet var contentView: UIView!
    @IBOutlet var chatCollView: UICollectionView!
    @IBOutlet var inputViewContainerBottomConstraint: NSLayoutConstraint!
    @IBOutlet var chatTF: UITextField!
    
    weak var delegate : ChatDataUpdate?
    var chatsArray: [Chat] = []
    private var userName: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.userName = chatsArray.first(where: { $0.is_sent_by_me == false })?.user_name ?? "Kent"
        self.navigationItem.title = self.userName
        self.assignDelegates()
        self.manageInputEventsForTheSubViews()
    }
    
    
    private func manageInputEventsForTheSubViews() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrameChangeNotfHandler(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrameChangeNotfHandler(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc private func keyboardFrameChangeNotfHandler(_ notification: Notification) {
        
        if let userInfo = notification.userInfo {
            let keyboardFrame = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
            let isKeyboardShowing = notification.name == UIResponder.keyboardWillShowNotification
            inputViewContainerBottomConstraint.constant = isKeyboardShowing ? keyboardFrame.height : 0
            UIView.animate(withDuration: 0, delay: 0, options: UIView.AnimationOptions.curveEaseOut, animations: {
                
                self.view.layoutIfNeeded()
            }, completion: { (completed) in
                
                if isKeyboardShowing {
                    let lastItem = self.chatsArray.count - 1
                    let indexPath = IndexPath(item: lastItem, section: 0)
                    self.chatCollView.scrollToItem(at: indexPath, at: .bottom, animated: true)
                }
            })
        }
    }
    
    private func assignDelegates() {
        
        self.chatCollView.register(ChatCell.self, forCellWithReuseIdentifier: ChatCell.identifier)
        self.chatCollView.dataSource = self
        self.chatCollView.delegate = self
        
        self.chatTF.delegate = self
    }
    
    @IBAction func onSendChat(_ sender: UIButton?) {
        guard let chatText = chatTF.text, chatText.count >= 1 else { return }
        chatTF.text = ""
        
        let chat1 = Chat.init(user_name: self.userName, is_sent_by_me: false, text: chatText)
        
        
        let chat2 = Chat.init(user_name: "Loks", is_sent_by_me: true, text: chatText)
        
       
        self.chatsArray.append(chat2)
        self.chatsArray.append(chat1)
        
        delegate?.didUpdate(chat: self.chatsArray)
        self.chatCollView.reloadData()
        
        let lastItem = self.chatsArray.count - 1
        let indexPath = IndexPath(item: lastItem, section: 0)
        self.chatCollView.scrollToItem(at: indexPath, at: .bottom, animated: true)
    }
}

extension ChatVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return chatsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = chatCollView.dequeueReusableCell(withReuseIdentifier: ChatCell.identifier, for: indexPath) as? ChatCell {
            
            let chat = chatsArray[indexPath.item]
            
            cell.messageTextView.text = chat.text
            cell.nameLabel.text = chat.user_name
            
            let size = CGSize(width: 250, height: 1000)
            let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
            var estimatedFrame = NSString(string: chat.text).boundingRect(with: size, options: options, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)], context: nil)
            estimatedFrame.size.height += 18
            
            let nameSize = NSString(string: chat.user_name).boundingRect(with: size, options: options, attributes: [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 15)], context: nil)
            
            let maxValue = max(estimatedFrame.width, nameSize.width)
            estimatedFrame.size.width = maxValue
            
            
            if !chat.is_sent_by_me {
                
                cell.nameLabel.textAlignment = .center
                
                cell.nameLabel.frame = CGRect(x: 10, y: 12, width: 50, height: estimatedFrame.height)
                cell.messageTextView.frame = CGRect(x: 70, y: 12, width: estimatedFrame.width + 16, height: estimatedFrame.height)
                cell.messageTextView.textColor = UIColor.black
            } else {
                
                cell.nameLabel.textAlignment = .right
                
                cell.nameLabel.frame = CGRect(x: collectionView.bounds.width - estimatedFrame.width - 16, y: 12, width: estimatedFrame.width + 16, height: estimatedFrame.height)
                cell.messageTextView.frame = CGRect(x: collectionView.bounds.width - estimatedFrame.width - 100, y: 12, width: estimatedFrame.width + 20, height: estimatedFrame.height)
                cell.messageTextView.textColor = UIColor.black
            }
            
            return cell
        }
        return ChatCell()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 0, bottom: 5, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.view.endEditing(true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let chat = chatsArray[indexPath.item]
        let size = CGSize(width: 250, height: 1000)
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        var estimatedFrame = NSString(string: chat.text).boundingRect(with: size, options: options, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)], context: nil)
        estimatedFrame.size.height += 18
        
        return CGSize(width: chatCollView.frame.width, height: estimatedFrame.height + 20)
    }
    
}

extension ChatVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if let txt = textField.text, txt.count >= 1 {
            textField.resignFirstResponder()
            return true
        }
        return false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        onSendChat(nil)
    }
}
