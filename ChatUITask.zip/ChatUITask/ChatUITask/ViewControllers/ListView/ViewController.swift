//
//  ViewController.swift
//  ChatUITask
//
//  Created by Lokesh Vyas on 04/12/21.
//

import UIKit

class ViewController: UIViewController {
  
    var chatsArray: [ChatList] = []
    var selectedIndex : Int?
    
    @IBOutlet weak var tblViewFriendList: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerTableViewCells()
        tblViewFriendList.delegate = self
        tblViewFriendList.dataSource = self
        self.fetchChatData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    private func fetchChatData() {
        if let url = Bundle.main.url(forResource: "chat", withExtension: "json") {
            do {
                
                let data = try Data.init(contentsOf: url)
                let decoder = JSONDecoder.init()
                self.chatsArray = try decoder.decode([ChatList].self, from: data)
                self.tblViewFriendList.reloadData()
                
            } catch let err {
                print(err.localizedDescription)
            }
            
        }
    }
    
    private func registerTableViewCells() {
        let textFieldCell = UINib(nibName: "FriendListCell",
                                  bundle: nil)
        self.tblViewFriendList.register(textFieldCell,
                                forCellReuseIdentifier: "FriendListCell")
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {

   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.chatsArray.count
   }
   
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
       let cell:FriendListCell = self.tblViewFriendList.dequeueReusableCell(withIdentifier: "FriendListCell") as! FriendListCell
       cell.lblName.text = self.chatsArray[indexPath.row].user_name
       cell.lblMsg.text = self.chatsArray[indexPath.row].chat.last?.text
       cell.selectionStyle = .none
       return cell
   }
   
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       self.selectedIndex = indexPath.row
       let vc = ChatVC.instantiate(fromAppStoryboard: .main)
       vc.delegate = self
       vc.chatsArray = self.chatsArray[indexPath.row].chat
       self.navigationController?.pushViewController(vc, animated: true)
   }
}

extension ViewController : ChatDataUpdate {
    func didUpdate(chat: [Chat]) {
        self.chatsArray[self.selectedIndex ?? 0].chat = chat
        self.tblViewFriendList.reloadData()
    }
}

