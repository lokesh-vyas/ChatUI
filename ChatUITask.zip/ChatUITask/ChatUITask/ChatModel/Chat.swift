//
//  Chat.swift
//  ChatUITask
//
//  Created by Lokesh Vyas on 04/12/21.
//

import UIKit

struct ChatList: Codable {
    var user_name: String
    var chat: [Chat]
}
struct Chat: Codable {
    
    var user_name: String
    var is_sent_by_me: Bool
    var text: String
}


protocol ChatDataUpdate : class {
    func didUpdate(chat : [Chat])
}
